
void ReadConfig(void);