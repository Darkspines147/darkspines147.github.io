# Microsoft Developer Studio Project File - Name="gxGCEmuOGL" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=GXGCEMUOGL - WIN32 RELEASE
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "gxGCEmuOGL.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "gxGCEmuOGL.mak" CFG="GXGCEMUOGL - WIN32 RELEASE"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "gxGCEmuOGL - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=xicl6.exe
MTL=midl.exe
RSC=rc.exe
# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "GXGCEMUOGL_EXPORTS" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /FR /FD /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=xilink6.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386
# ADD LINK32 user32.lib gdi32.lib opengl32.lib winmm.lib advapi32.lib /nologo /dll /machine:I386
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Desc=copy
PostBuild_Cmds=copy release\*.dll d:\gcemutest\plugins	copy release\gxGCEmuOGL.dll d:\gcemutest\plugins\gxDefault.dll
# End Special Build Tool
# Begin Target

# Name "gxGCEmuOGL - Win32 Release"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\cfg.c
# End Source File
# Begin Source File

SOURCE=.\cp_regs.c
# End Source File
# Begin Source File

SOURCE=.\fps.c
# End Source File
# Begin Source File

SOURCE=.\fragment_shader_gen.c
# End Source File
# Begin Source File

SOURCE=.\gx_cache.c
# End Source File
# Begin Source File

SOURCE=.\gx_fifo_interface.c
# End Source File
# Begin Source File

SOURCE=.\gxGCEmuOGL.c
# End Source File
# Begin Source File

SOURCE=.\gxGCEmuOGL.def
# End Source File
# Begin Source File

SOURCE=.\ogl_bp_regs.c
# End Source File
# Begin Source File

SOURCE=.\ogl_generic.c
# End Source File
# Begin Source File

SOURCE=.\ogl_vertex_processor.c
# End Source File
# Begin Source File

SOURCE=.\ogl_xf_regs.c
# End Source File
# Begin Source File

SOURCE=.\pe_interface.c
# End Source File
# Begin Source File

SOURCE=.\texture_cache.c
# End Source File
# Begin Source File

SOURCE=.\texture_conversion.c
# End Source File
# Begin Source File

SOURCE=.\texture_environment.c
# End Source File
# Begin Source File

SOURCE=.\video_interface.c
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\bp_regs.h
# End Source File
# Begin Source File

SOURCE=.\cfg.h
# End Source File
# Begin Source File

SOURCE=.\cp_regs.h
# End Source File
# Begin Source File

SOURCE=.\externals.h
# End Source File
# Begin Source File

SOURCE=.\fps.h
# End Source File
# Begin Source File

SOURCE=.\fragment_shader_gen.h
# End Source File
# Begin Source File

SOURCE=.\gx_cache.h
# End Source File
# Begin Source File

SOURCE=.\gx_fifo_interface.h
# End Source File
# Begin Source File

SOURCE=.\ogl_generic.h
# End Source File
# Begin Source File

SOURCE=.\pe_interface.h
# End Source File
# Begin Source File

SOURCE=.\resource.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\texture_cache.h
# End Source File
# Begin Source File

SOURCE=.\texture_conversion.h
# End Source File
# Begin Source File

SOURCE=.\texture_environment.h
# End Source File
# Begin Source File

SOURCE=.\types.h
# End Source File
# Begin Source File

SOURCE=.\vertex_processor.h
# End Source File
# Begin Source File

SOURCE=.\video_interface.h
# End Source File
# Begin Source File

SOURCE=.\xf_regs.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\gxGCEmuOGL.rc
# End Source File
# End Group
# End Target
# End Project
