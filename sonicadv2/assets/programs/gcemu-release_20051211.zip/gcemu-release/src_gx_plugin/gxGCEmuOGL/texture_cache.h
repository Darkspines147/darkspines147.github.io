
void   tc_init(void);
void   tc_close(void);
bool   tc_check(uint32 tex_addr, uint32 tex_size, uint32 *tex);
void   tc_store_entry(uint32 tex_addr, void *pc_addr, uint32 tex);
void   tc_invalidate_entry(uint32 tex_addr);
bool   tc_check_fbtex(uint32 tex_addr, int wid, int hei, uint32 *tex_name);

