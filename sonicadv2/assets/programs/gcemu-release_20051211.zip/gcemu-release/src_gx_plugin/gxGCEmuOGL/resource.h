//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gxPeteOGL.rc
//
#define IDS_INFO                        1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2071
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
