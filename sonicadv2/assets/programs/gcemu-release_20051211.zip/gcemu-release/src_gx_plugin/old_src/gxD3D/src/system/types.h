#pragma once

typedef unsigned char	uint8;
typedef unsigned short	uint16;
typedef unsigned int	uint32;
typedef unsigned long long uint64;
typedef unsigned int	uint;

typedef signed char	sint8;
typedef signed short	sint16;
typedef signed int	sint32;
typedef signed long long sint64;
