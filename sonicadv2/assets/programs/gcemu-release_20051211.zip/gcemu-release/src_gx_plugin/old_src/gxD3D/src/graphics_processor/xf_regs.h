#pragma once

#include "system/types.h"
#include "gp_defs.h"

extern gp_reg	gp_xf_regs[];
void gp_xf_write_reg(uint32 reg, uint32 data);
