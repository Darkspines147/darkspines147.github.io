/*====================================================================

filename:     gdsp_opcodes.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

bool dsp_op0(uint16 opc);
bool dsp_op1(uint16 opc);
bool dsp_op2(uint16 opc);
bool dsp_op3(uint16 opc);
bool dsp_op4(uint16 opc);
bool dsp_op5(uint16 opc);
bool dsp_op6(uint16 opc);
bool dsp_op7(uint16 opc);
bool dsp_op8(uint16 opc);
bool dsp_op9(uint16 opc);
bool dsp_opa(uint16 opc);
bool dsp_opb(uint16 opc);
bool dsp_opc(uint16 opc);
bool dsp_opd(uint16 opc);
bool dsp_ope(uint16 opc);
bool dsp_opf(uint16 opc);
