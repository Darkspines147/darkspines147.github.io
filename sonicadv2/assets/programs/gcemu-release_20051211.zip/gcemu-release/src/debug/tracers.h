/*====================================================================

filename:     tracers.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

#include "system/types.h"
#include "debug/syslog.h"

enum LOG_TYPE
{
	MAIN,
	LOAD,
	CPU,
	IO_CORE,
	CMP,
	EXI,
	ARAM,
	DSPI,
	DI,
	SI,
	CP,
	TE,
	MC,
	VI,
	BP,
	VX,
	GX,
	XF,
	WGL,
	GX_PLUGIN,
	LOG_TYPE_MAX
};

char *log_id[];
uint32 log_trace_on[];
