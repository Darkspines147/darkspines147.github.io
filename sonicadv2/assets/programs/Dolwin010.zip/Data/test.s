
stat vi