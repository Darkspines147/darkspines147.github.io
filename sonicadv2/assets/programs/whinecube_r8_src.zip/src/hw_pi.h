// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as
// published by the Free Software Foundation.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#ifndef HW_PI_H
#define HW_PI_H

#include "hw_internal.h"

class HwPI {
public:
	static void ww_reset(Hardware *h, WORD offset, DWORD data);
	static DWORD rw_reset(Hardware *h, WORD offset);
	static DWORD rw_intsr(Hardware *h, WORD offset);
	static void ww_intsr(Hardware *h, WORD offset, DWORD data);
	static void ww_intmr(Hardware *h, WORD offset, DWORD data);
	static DWORD rw_console_type(Hardware *h, WORD offset);
};

#endif	//HW_PI_H
